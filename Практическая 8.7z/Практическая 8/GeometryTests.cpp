﻿#include "pch.h"
#include "CppUnitTest.h"
#include "GeometryAreaCalculator.h"
#include "PerimeterCalculator.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace GeometryTests
{
    TEST_CLASS(GeometryAreaCalculatorTests)
    {
    public:
        // ПОЗИТИВНЫЕ ТЕСТЫ ДЛЯ ПЛОЩАДЕЙ
        TEST_METHOD(TestTriangleArea_ValidInput_ReturnsCorrectArea)
        {
            double result = GeometryAreaCalculator::triangleArea(5.0, 3.0);
            Assert::AreEqual(7.5, result, 0.0001);
        }

        TEST_METHOD(TestCircleArea_ValidInput_ReturnsCorrectArea)
        {
            double result = GeometryAreaCalculator::circleArea(2.0);
            Assert::AreEqual(M_PI * 4.0, result, 0.0001);
        }

        // НЕГАТИВНЫЕ ТЕСТЫ ДЛЯ ПЛОЩАДЕЙ
        TEST_METHOD(TestTriangleArea_NegativeBase_ThrowsException)
        {
            auto func = []() { GeometryAreaCalculator::triangleArea(-5.0, 3.0); };
            Assert::ExpectException<std::invalid_argument>(func);
        }

        TEST_METHOD(TestCircleArea_ZeroRadius_ThrowsException)
        {
            auto func = []() { GeometryAreaCalculator::circleArea(0.0); };
            Assert::ExpectException<std::invalid_argument>(func);
        }
    };

    TEST_CLASS(PerimeterCalculatorTests)
    {
    public:
        // ПОЗИТИВНЫЕ ТЕСТЫ ДЛЯ ПЕРИМЕТРОВ
        TEST_METHOD(TestSquarePerimeter_ValidInput_ReturnsCorrectPerimeter)
        {
            double result = PerimeterCalculator::squarePerimeter(5.0);
            Assert::AreEqual(20.0, result, 0.0001);
        }

        TEST_METHOD(TestRectanglePerimeter_ValidInput_ReturnsCorrectPerimeter)
        {
            double result = PerimeterCalculator::rectanglePerimeter(6.0, 4.0);
            Assert::AreEqual(20.0, result, 0.0001);
        }

        // НЕГАТИВНЫЕ ТЕСТЫ ДЛЯ ПЕРИМЕТРОВ
        TEST_METHOD(TestSquarePerimeter_NegativeSide_ThrowsException)
        {
            auto func = []() { PerimeterCalculator::squarePerimeter(-5.0); };
            Assert::ExpectException<std::invalid_argument>(func);
        }

        TEST_METHOD(TestCircleCircumference_ZeroRadius_ThrowsException)
        {
            auto func = []() { PerimeterCalculator::circleCircumference(0.0); };
            Assert::ExpectException<std::invalid_argument>(func);
        }

        // ТЕСТ НАПАРНИКА ДЛЯ ФУНКЦИИ trianglePerimeter
        TEST_METHOD(TestTrianglePerimeter_InvalidTriangle_ThrowsException)
        {
            auto func = []() { PerimeterCalculator::trianglePerimeter(1.0, 1.0, 3.0); };
            Assert::ExpectException<std::invalid_argument>(func);
        }
    };
}