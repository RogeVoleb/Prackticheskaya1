﻿#include <iostream>
#include <iomanip>
#include "GeometryAreaCalculator.h"
#include "PerimeterCalculator.h"

using namespace std;

void printHeader(const string& title) {
    cout << "\n" << string(60, '=') << endl;
    cout << title << endl;
    cout << string(60, '=') << endl;
}

void demoAreaCalculator() {
    printHeader("ДЕМОНСТРАЦИЯ ВЫЧИСЛЕНИЯ ПЛОЩАДЕЙ");

    cout << fixed << setprecision(2);

    // Площади
    cout << "Площадь треугольника (основание=5, высота=3): "
        << GeometryAreaCalculator::triangleArea(5.0, 3.0) << endl;

    cout << "Площадь треугольника (стороны=3,4,5): "
        << GeometryAreaCalculator::triangleArea(3.0, 4.0, 5.0) << endl;

    cout << "Площадь прямоугольника (длина=6, ширина=4): "
        << GeometryAreaCalculator::rectangleArea(6.0, 4.0) << endl;

    cout << "Площадь круга (радиус=2): "
        << GeometryAreaCalculator::circleArea(2.0) << endl;

    cout << "Площадь трапеции (основания=3 и 5, высота=4): "
        << GeometryAreaCalculator::trapezoidArea(3.0, 5.0, 4.0) << endl;
}

void demoPerimeterCalculator() {
    printHeader("ДЕМОНСТРАЦИЯ ВЫЧИСЛЕНИЯ ПЕРИМЕТРОВ");

    cout << fixed << setprecision(2);

    // Периметры
    cout << "Периметр квадрата (сторона=5): "
        << PerimeterCalculator::squarePerimeter(5.0) << endl;

    cout << "Периметр прямоугольника (длина=6, ширина=4): "
        << PerimeterCalculator::rectanglePerimeter(6.0, 4.0) << endl;

    cout << "Периметр треугольника (стороны=3,4,5): "
        << PerimeterCalculator::trianglePerimeter(3.0, 4.0, 5.0) << endl;

    cout << "Длина окружности (радиус=3): "
        << PerimeterCalculator::circleCircumference(3.0) << endl;

    cout << "Периметр равностороннего треугольника (сторона=4): "
        << PerimeterCalculator::equilateralTrianglePerimeter(4.0) << endl;

    cout << "Периметр правильного пятиугольника (сторона=2): "
        << PerimeterCalculator::regularPolygonPerimeter(2.0, 5) << endl;
}

void demoErrorHandling() {
    printHeader("ДЕМОНСТРАЦИЯ ОБРАБОТКИ ОШИБОК");

    try {
        GeometryAreaCalculator::triangleArea(-1.0, 2.0);
    }
    catch (const exception& e) {
        cout << "Ошибка площади треугольника: " << e.what() << endl;
    }

    try {
        PerimeterCalculator::squarePerimeter(-2.0);
    }
    catch (const exception& e) {
        cout << "Ошибка периметра квадрата: " << e.what() << endl;
    }

    try {
        GeometryAreaCalculator::triangleArea(1.0, 1.0, 3.0);
    }
    catch (const exception& e) {
        cout << "Ошибка треугольника: " << e.what() << endl;
    }

    try {
        PerimeterCalculator::regularPolygonPerimeter(2.0, 2);
    }
    catch (const exception& e) {
        cout << "Ошибка многоугольника: " << e.what() << endl;
    }
}

int main() {
    setlocale(0, "");

    cout << "ГЕОМЕТРИЧЕСКИЙ КАЛЬКУЛЯТОР - ПЛОЩАДИ И ПЕРИМЕТРЫ" << endl;

    demoAreaCalculator();
    demoPerimeterCalculator();
    demoErrorHandling();

    cout << "\n" << string(60, '=') << endl;
    cout << "ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА УСПЕШНО!" << endl;
    cout << string(60, '=') << endl;

    return 0;
}