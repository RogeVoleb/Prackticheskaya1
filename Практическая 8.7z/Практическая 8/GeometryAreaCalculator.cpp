﻿#include "GeometryAreaCalculator.h"
#include <cmath>
#include <stdexcept>

using namespace std;

double GeometryAreaCalculator::triangleArea(double base, double height) {
    if (base <= 0 || height <= 0) {
        throw invalid_argument("Основание и высота должны быть положительными");
    }
    return 0.5 * base * height;
}

double GeometryAreaCalculator::triangleArea(double a, double b, double c) {
    if (a <= 0 || b <= 0 || c <= 0) {
        throw invalid_argument("Стороны треугольника должны быть положительными");
    }
    if (a + b <= c || a + c <= b || b + c <= a) {
        throw invalid_argument("Треугольник с такими сторонами не существует");
    }
    double p = (a + b + c) / 2.0;
    return sqrt(p * (p - a) * (p - b) * (p - c));
}

double GeometryAreaCalculator::rectangleArea(double length, double width) {
    if (length <= 0 || width <= 0) {
        throw invalid_argument("Длина и ширина должны быть положительными");
    }
    return length * width;
}

double GeometryAreaCalculator::circleArea(double radius) {
    if (radius <= 0) {
        throw invalid_argument("Радиус должен быть положительным");
    }
    return M_PI * radius * radius;
}

double GeometryAreaCalculator::trapezoidArea(double base1, double base2, double height) {
    if (base1 <= 0 || base2 <= 0 || height <= 0) {
        throw invalid_argument("Основания и высота должны быть положительными");
    }
    return 0.5 * (base1 + base2) * height;
}